<?php 
    	global $current_user;
    	get_currentuserinfo();
        $cb_author_id = $current_user->ID;
        $cb_author_posts = count_user_posts( $cb_author_id ); 
        $cb_nav_style = ot_get_option('cb_menu_style', 'cb_dark'); 
        if ($cb_nav_style == 'cb_light') {
            $cb_menu_color = 'cb-light-menu'; 
        } else {
             $cb_menu_color = 'cb-dark-menu';
        }

?>

<div class="cb-login-modal clearfix <?php echo $cb_menu_color; ?>">
    <div class="lwa cb-logged-in clearfix">

        <?php if ( class_exists('bbpress') ) { ?>
        
        <div class="cb-header">
                <div class="cb-title"><?php echo  $current_user->display_name;  ?></div>
                <div class="cb-close"><span class="cb-close-modal"><i class="icon-remove"></i></span></div>
        </div>
        <div class="cb-lwa-profile">

            <div class="cb-avatar">
                    <?php echo get_avatar( $cb_author_id, $size = '150' );  ?>
            </div>

            <div class="cb-user-data clearfix">
            	
                
                <div class="cb-block"><i class="icon-user"></i>
                    <a class="url fn n" href="<?php bbp_user_profile_url($cb_author_id); ?>" rel="me"><?php _e( 'Profile', 'bbpress' ); ?></a>
                </div>

                <div class="cb-block"><i class="icon-comment"></i>
                    <a href="<?php bbp_user_topics_created_url($cb_author_id); ?>"><?php _e( 'Topics Started', 'bbpress' ); ?></a>
                </div>

                <div class="cb-block"><i class="icon-comments"></i>
                    <a href="<?php bbp_user_replies_created_url($cb_author_id); ?>"><?php _e( 'Replies Created', 'bbpress' ); ?></a>
                </div>

                <div class="cb-block"><i class="icon-heart"></i>
                    <a href="<?php bbp_favorites_permalink($cb_author_id); ?>"><?php _e( 'Favorites', 'bbpress' ); ?></a>
                </div>

                <div class="cb-block"><i class="icon-bookmark"></i>
                    <a href="<?php bbp_subscriptions_permalink($cb_author_id); ?>"><?php _e( 'Subscriptions', 'bbpress' ); ?></a>
                </div>

                <div class="cb-block cb-last-block"><i class="icon-signout"></i>
                    <a class="wp-logout" href="<?php echo wp_logout_url() ?>"><?php esc_html_e( 'Log Out' ,'login-with-ajax') ?></a>
                </div>

            </div>

        </div>
    
        <?php } else { ?>

        <div class="cb-header">
                <div class="cb-title"><?php echo  $current_user->display_name;  ?></div>
                <div class="cb-close"><span class="cb-close-modal"><i class="icon-remove"></i></span></div>
        </div>
        <div class="cb-lwa-profile">

             <div class="cb-avatar">
                    <?php echo get_avatar( $cb_author_id, $size = '150' );  ?>
            </div>

            <div class="cb-user-data clearfix">
            
                <div class="cb-block"><i class="icon-user"></i>
                    <a href="<?php echo get_edit_user_link($cb_author_id); ?>"><?php esc_html_e("Edit Profile", 'cubell'); ?></a>
                </div>  
                
                <div class="cb-block"><i class="icon-signout"></i>
                    <a class="wp-logout" href="<?php echo wp_logout_url() ?>"><?php esc_html_e( 'Log Out' ,'login-with-ajax') ?></a>
                </div>
                
            </div>  
        </div>


        <?php } ?>
            
    </div>
</div>